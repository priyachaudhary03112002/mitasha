<?php
include_once('model.php');
class control extends model
{
     function __construct(){
     	model:: __construct();
     	$path=$_SERVER['PATH_INFO'];

     	 switch ($path) {

     	 	case '/':
            include_once('index.php');
     	 	break;
          
           case '/index':
           include_once('index.php');
     	 	break;

         case '/room':
           include_once('room.php');
        break;
 
        case '/booking_detail':
        $booking_arr=$this->select('booking');
           include_once('booking_detail.php');
        break;


           case '/booking': 
      if(isset($_REQUEST['submit']))
      {
        $check_in=$_REQUEST['check_in'];    
        $check_out =$_REQUEST['check_out'];
       $room_name =$_REQUEST['room_name'];
       $shift_name =$_REQUEST['shift_name'];
       $start_time =$_REQUEST['start_time'];
       $end_time =$_REQUEST['end_time'];
        
             
        $data=array("check_in"=>$check_in, "check_out"=>$check_out, "shift_name"=>$shift_name, "room_name" => $room_name,"start_time"=>$start_time,"end_time"=>$end_time);
      //print_r($data);
        
        $res=$this->insert('booking',$data);
        
        if($res)  
        {
          echo "<script> alert('booking form Success');
              
          </script>";
        }
        else
        {
          echo "FGAILED";
        }
      } 
      
          
  
           include_once('booking.php');
     	 	break;

     	
        
     	 }
     }     
}	

$obj= new control;

?>