  <?php
 
  include_once('header.php');

?>

<div class="hero-wrap" style="background-image: url('images/bg_1.jpg');">
      <div class="overlay"></div>
         </div>

 <div class="content-body">
            <div class="container-fluid">
                
                <!-- row -->
                
               

                <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">View Book Report</h4>
                         
                            </div> 

                             
                            <div class="card-body">

                                <div class="table-responsive">
                                   <table class="table table-bordered verticle-middle table-responsive-sm">
                                        <thead>
                                            <tr>
                                                <th scope="col">Book Id</th>
                                                <th scope="col">Room name</th>
                                                <th scope="col">Shift Name</th>
                                                <th scope="col">Check In</th>
                                                <th scope="col">Check Out</th>
                                                <th scope="col">Start Time</th>
                                                <th scope="col">End Time</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                  <?php
                                                foreach($booking_arr as $data)
                                                {
                                              ?> 
                                            <tr>
                                                <td cope="row"><?php echo $data->book_id ;?></td>
                                                <td><?php echo $data->room_name;?></td>
                                                <td><?php echo $data->shift_name;?></td>
                                                <td><?php echo $data->check_in;?></td>
                                                <td><?php echo $data->check_out;?></td>
                                                <td><?php echo $data->start_time;?></td>
                                                <td><?php echo $data->end_time;?></td>
                                               </tr>

                                        </tbody>
                                          <?php
                                           } 
                                           ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
<?php
 
  include_once('footer.php');

?>                  