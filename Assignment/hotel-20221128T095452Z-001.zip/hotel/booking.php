<?php
include_once('header.php');

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script>
 

          $(document).ready(function(){
          	$("#room_name").change(function(){
           if($("#room_name").val() == "Fullday"){ 
           			$("#shift_name").hide();
           			$("#start_time").hide();
           			$("#end_time").hide();
           			$("#check_out").show();
			  }
           });

       

           $("#room_name").change(function(){
           if($("#room_name").val() == "Halfday"){ 
           			$("#shift_name").show();
           			$("#start_time").show();
           			$("#end_time").show();
           			$("#check_out").hide();
			  }
           });
            
          $("#room_name").change(function(){
           if($("#room_name").val() == "roomtype"){ 
           			$("#shift_name").show();
           			$("#start_time").show();
           			$("#end_time").show();
           			$("#check_out").show();
           			$("#check_in").show();
			  }
           });
        
          });  
	</script>	
</head>
<body>

<div class="hero-wrap" style="background-image: url('images/bg_1.jpg');">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text d-flex align-itemd-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center d-flex align-items-end justify-content-center">
          	<div class="text">
	            <p class="breadcrumbs mb-2"><span class="mr-2"><a href="index.php">Home</a></span> <span>About</span></p>
	            <h1 class="mb-4 bread">Booking</h1>
            </div>
          </div>
        </div>
      </div>
    </div>
    <section class="ftco-section bg-light">
    	<div class="container">
    		<div class="row">
	        <div class="col-lg-3">		    		
	    	</div>

		    	<div class="col-lg-6">
	      		<div class="sidebar-wrap bg-light ftco-animate">
	      			<h3 class="heading mb-4">Booking Form</h3>
	      			<form action="#" method="post">
	      				<div class="fields">
	      	               <div class="form-group">
		                <div class="select-wrap one-third">
	                    <div class="icon"><span class="ion-ios-arrow-down"></span></div>
	                    <select name="room_name" id="room_name" class="form-control">
	                    	<option name="roomtype" id="roomtype"  value="roomtype">Room Type</option>
	               	      <option  name="Fullday" id="Fullday"  value="Fullday">Full day</option>
	                      <option name="Halfday" id="Halfday" value="Halfday">Half day</option>
	                      <option value="Custom">Custom</option>
	                  </select>
	                  </div>
		              </div>
		                 <div class="form-group">
		                <div class="select-wrap one-third">
	                    <div class="icon"><span class="ion-ios-arrow-down"></span></div>
	                    <select name="shift_name"  id="shift_name" class="form-control">
	                    	<option value="">shift</option>
	               	      <option value="First half">First half- morning</option>
	                      <option value="Second half">Second half - evening</option>
	                  </select>
	                  </div>
		              </div>
		              <div class="form-group">
		                 <input type="date" name="check_in" class="form-control" placeholder="Check In Date">
		              </div>
		              <div class="form-group">
		                <input type="date" name="check_out" id="check_out" class="form-control" placeholder="Check Out Date">
		              </div>

		               <div class="form-group">
	                    <input type="time" name="start_time"  id="start_time" class="form-control">
	                </div>
	                    <div class="form-group">
	                    <input type="time" name="end_time" id="end_time" class="form-control">
 		              </div>
		              
		              <div class="form-group">
		                <input type="submit" name="submit"  class="btn btn-primary py-3 px-5">
		              </div>
		            </div>
	            </form>
	      		</div>
               
	  </section>
	</body>
	</html>
    	
<?php
include_once('footer.php');
?>
